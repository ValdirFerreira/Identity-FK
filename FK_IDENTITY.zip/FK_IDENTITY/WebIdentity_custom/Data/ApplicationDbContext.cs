﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using WebIdentity_custom.Models;

namespace WebIdentity_custom.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {

        public DbSet<Contato> Contato { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}
